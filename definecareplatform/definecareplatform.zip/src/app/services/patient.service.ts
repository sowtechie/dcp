import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class PatientService {

    constructor(private httpClient: HttpClient) {}

    submitPatientData(patientData) {
        return this.httpClient.post('/patient/submitForm', patientData);
    }
}