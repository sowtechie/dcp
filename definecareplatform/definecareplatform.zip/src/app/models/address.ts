export class Address {
    hno: string;
    streetName:string;
    city;
    state;
    zipCode;
}