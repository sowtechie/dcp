import { IPhone } from './types/IPhone';

export class IPhone8 implements IPhone {
    calling() {
        console.log("calling phone IPhone8");

    }
}