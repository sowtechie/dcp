import { IPhone } from './types/IPhone';

export class IPhone5 implements IPhone {
    calling() {
        console.log('calling from IPhone5');
    }

}