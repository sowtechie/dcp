import { Address } from './address';

export class Person{
    name;
    id;
    emailId;
    phNo;
    address?: Address;
    role:string;
}