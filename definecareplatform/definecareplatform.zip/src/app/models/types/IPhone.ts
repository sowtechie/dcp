export interface IPhone {
    calling();

}
