
export interface IAddress{
    hno: string;
    streetName:string;
    city;
    state;
    zipCode;

}