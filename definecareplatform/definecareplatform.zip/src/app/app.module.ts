import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {MatButtonModule, MatCheckboxModule} from '@angular/material';
import {MatToolbarModule} from '@angular/material/toolbar';
import { AppDataService } from './app-data.service';
import { FooterModule } from './footer/footer.module';
import {MatRadioModule} from '@angular/material/radio';
import { SearchComponent } from './search/search.component';
import { SearchModule } from './search/search.module';
import { PatientService } from './services/patient.service';

@NgModule({
  declarations: [
    AppComponent,
    
  ],
  imports: [
    BrowserAnimationsModule,
    BrowserModule,
    MatToolbarModule,
    MatButtonModule, MatCheckboxModule,
    AppRoutingModule,
    MatRadioModule,
    FooterModule,
    SearchModule,

  ],
  providers: [AppDataService, PatientService],
  bootstrap: [AppComponent]
})
export class AppModule { }
