import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { PatientService } from '../services/patient.service';

@Component({
  selector: 'app-patientform',
  templateUrl: './patientform.component.html',
  styleUrls: ['./patientform.component.scss']
})
export class PatientformComponent implements OnInit {

  patientFormData = {};

  constructor(private patientService: PatientService) { }

  ngOnInit() {

  }

  patientUpdated(patientChanges) {
    this.patientFormData['patient'] = patientChanges;
    console.log('from parent form, changes are -> ', this.patientFormData)
    
  }

  healthUpdated(healthChanges) {
    this.patientFormData['health'] = healthChanges;
    console.log('from parent form, changes are -> ', this.patientFormData)
    
  }

  submitForm() {
    console.log('Im submitting the form with this data -> ', this.patientFormData)
    this.patientService.submitPatientData(this.patientFormData).subscribe(backendResponse => {
      console.log('patient submit response is', backendResponse);
    })
  }

}
