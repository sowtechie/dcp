import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-insurance-basics',
  templateUrl: './insurance-basics.component.html',
  styleUrls: ['./insurance-basics.component.scss']
})
export class InsuranceBasicsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
